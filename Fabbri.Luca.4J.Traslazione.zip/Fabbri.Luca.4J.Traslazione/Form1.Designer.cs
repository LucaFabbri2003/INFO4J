﻿namespace Fabbri.Luca._4J.Traslazione
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.Titolo = new System.Windows.Forms.Label();
            this.Piano = new System.Windows.Forms.Panel();
            this.Bottone1 = new System.Windows.Forms.Button();
            this.Testo1 = new System.Windows.Forms.Label();
            this.Testo2 = new System.Windows.Forms.Label();
            this.Testo3 = new System.Windows.Forms.Label();
            this.Bottone2 = new System.Windows.Forms.Button();
            this.Bottone3 = new System.Windows.Forms.Button();
            this.vertice1 = new System.Windows.Forms.Label();
            this.vertice2 = new System.Windows.Forms.Label();
            this.vertice3 = new System.Windows.Forms.Label();
            this.Bottone4 = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.Bottone5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Titolo
            // 
            this.Titolo.AutoSize = true;
            this.Titolo.Cursor = System.Windows.Forms.Cursors.Default;
            this.Titolo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Titolo.Location = new System.Drawing.Point(198, 9);
            this.Titolo.Name = "Titolo";
            this.Titolo.Size = new System.Drawing.Size(285, 25);
            this.Titolo.TabIndex = 0;
            this.Titolo.Text = "Esercitazione Traslazione";
            this.Titolo.Click += new System.EventHandler(this.Titolo_Click);
            // 
            // Piano
            // 
            this.Piano.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Piano.Location = new System.Drawing.Point(12, 37);
            this.Piano.Name = "Piano";
            this.Piano.Size = new System.Drawing.Size(657, 401);
            this.Piano.TabIndex = 1;
            this.Piano.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Piano_MouseDown);
            // 
            // Bottone1
            // 
            this.Bottone1.Location = new System.Drawing.Point(713, 94);
            this.Bottone1.Name = "Bottone1";
            this.Bottone1.Size = new System.Drawing.Size(75, 23);
            this.Bottone1.TabIndex = 0;
            this.Bottone1.Text = "Seleziona";
            this.Bottone1.UseVisualStyleBackColor = true;
            this.Bottone1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Testo1
            // 
            this.Testo1.AutoSize = true;
            this.Testo1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Testo1.Location = new System.Drawing.Point(676, 37);
            this.Testo1.Name = "Testo1";
            this.Testo1.Size = new System.Drawing.Size(100, 24);
            this.Testo1.TabIndex = 2;
            this.Testo1.Text = "1° Vertice";
            // 
            // Testo2
            // 
            this.Testo2.AutoSize = true;
            this.Testo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Testo2.Location = new System.Drawing.Point(676, 148);
            this.Testo2.Name = "Testo2";
            this.Testo2.Size = new System.Drawing.Size(100, 24);
            this.Testo2.TabIndex = 3;
            this.Testo2.Text = "2° Vertice";
            // 
            // Testo3
            // 
            this.Testo3.AutoSize = true;
            this.Testo3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Testo3.Location = new System.Drawing.Point(676, 262);
            this.Testo3.Name = "Testo3";
            this.Testo3.Size = new System.Drawing.Size(100, 24);
            this.Testo3.TabIndex = 4;
            this.Testo3.Text = "3° Vertice";
            // 
            // Bottone2
            // 
            this.Bottone2.Location = new System.Drawing.Point(713, 206);
            this.Bottone2.Name = "Bottone2";
            this.Bottone2.Size = new System.Drawing.Size(75, 23);
            this.Bottone2.TabIndex = 5;
            this.Bottone2.Text = "Seleziona";
            this.Bottone2.UseVisualStyleBackColor = true;
            this.Bottone2.Click += new System.EventHandler(this.Bottone2_Click);
            // 
            // Bottone3
            // 
            this.Bottone3.Location = new System.Drawing.Point(713, 320);
            this.Bottone3.Name = "Bottone3";
            this.Bottone3.Size = new System.Drawing.Size(75, 23);
            this.Bottone3.TabIndex = 6;
            this.Bottone3.Text = "Seleziona";
            this.Bottone3.UseVisualStyleBackColor = true;
            this.Bottone3.Click += new System.EventHandler(this.Bottone3_Click);
            // 
            // vertice1
            // 
            this.vertice1.AutoSize = true;
            this.vertice1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vertice1.Location = new System.Drawing.Point(701, 71);
            this.vertice1.Name = "vertice1";
            this.vertice1.Size = new System.Drawing.Size(81, 20);
            this.vertice1.TabIndex = 3;
            this.vertice1.Text = "Vertice 1";
            // 
            // vertice2
            // 
            this.vertice2.AutoSize = true;
            this.vertice2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vertice2.Location = new System.Drawing.Point(701, 183);
            this.vertice2.Name = "vertice2";
            this.vertice2.Size = new System.Drawing.Size(81, 20);
            this.vertice2.TabIndex = 7;
            this.vertice2.Text = "Vertice 2";
            // 
            // vertice3
            // 
            this.vertice3.AutoSize = true;
            this.vertice3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vertice3.Location = new System.Drawing.Point(701, 297);
            this.vertice3.Name = "vertice3";
            this.vertice3.Size = new System.Drawing.Size(81, 20);
            this.vertice3.TabIndex = 8;
            this.vertice3.Text = "Vertice 3";
            // 
            // Bottone4
            // 
            this.Bottone4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bottone4.Location = new System.Drawing.Point(680, 358);
            this.Bottone4.Name = "Bottone4";
            this.Bottone4.Size = new System.Drawing.Size(75, 29);
            this.Bottone4.TabIndex = 10;
            this.Bottone4.Text = "Riempi";
            this.Bottone4.UseVisualStyleBackColor = true;
            this.Bottone4.Click += new System.EventHandler(this.Bottone4_Click);
            // 
            // Bottone5
            // 
            this.Bottone5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bottone5.Location = new System.Drawing.Point(680, 406);
            this.Bottone5.Name = "Bottone5";
            this.Bottone5.Size = new System.Drawing.Size(75, 29);
            this.Bottone5.TabIndex = 11;
            this.Bottone5.Text = "Trasla";
            this.Bottone5.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(835, 447);
            this.Controls.Add(this.Bottone5);
            this.Controls.Add(this.Bottone4);
            this.Controls.Add(this.vertice3);
            this.Controls.Add(this.vertice2);
            this.Controls.Add(this.vertice1);
            this.Controls.Add(this.Bottone3);
            this.Controls.Add(this.Bottone2);
            this.Controls.Add(this.Testo3);
            this.Controls.Add(this.Testo2);
            this.Controls.Add(this.Testo1);
            this.Controls.Add(this.Bottone1);
            this.Controls.Add(this.Piano);
            this.Controls.Add(this.Titolo);
            this.Name = "Form1";
            this.Text = "Esercitazione";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Titolo;
        private System.Windows.Forms.Panel Piano;
        private System.Windows.Forms.Button Bottone1;
        private System.Windows.Forms.Label Testo1;
        private System.Windows.Forms.Label Testo2;
        private System.Windows.Forms.Label Testo3;
        private System.Windows.Forms.Button Bottone2;
        private System.Windows.Forms.Button Bottone3;
        private System.Windows.Forms.Label vertice1;
        private System.Windows.Forms.Label vertice2;
        private System.Windows.Forms.Label vertice3;
        private System.Windows.Forms.Button Bottone4;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Button Bottone5;
    }
}

