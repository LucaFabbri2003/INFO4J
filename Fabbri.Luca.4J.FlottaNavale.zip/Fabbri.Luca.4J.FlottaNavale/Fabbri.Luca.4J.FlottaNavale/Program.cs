﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimpleJSON;
using System.IO;
using System.Threading;
using Fabbri.Luca._4J.FlottaNavale.models;

namespace Fabbri.Luca._4J.FlottaNavale
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             * Elaborare le classi Nave e Comandante per modellare una flotta. Si chiede di estrarre 
             * il comandante data la nave e viceversa. (Prendere i dati da due file di testo o JSON)
             * 
             *                           *****-DA FINIRE!-*****
             * - Guardare i due cicli e verificare di estarre comandante, nave e viceversa.
            */

            string strRisposta, strNave, strComandante ;

            Console.WriteLine("Benvenuto nel programma 'Flotta Navale' di Fabbri Luca 4J");
            Console.WriteLine("");

            Thread.Sleep(2000);

            Console.WriteLine("Lettura dei file in corso......");
            Console.WriteLine("");

            Thread.Sleep(5000);

            Console.WriteLine("Desideri visualizzare i due file? (navi.txt e comandanti.txt)");
            strRisposta = Console.ReadLine();

            Console.WriteLine("");

            if(strRisposta == "Sì" || strRisposta == "Si" || strRisposta == "sì" || strRisposta == "si")
            {
                Console.WriteLine("Attendere, stampa in corso.....");
                Console.WriteLine("");

                Thread.Sleep(2000);
                StreamReader navi = new StreamReader("navi.txt");
                StreamReader comandanti = new StreamReader("comandanti.txt");
                //Console.WriteLine(input.ReadToEnd());
                string contenuto1 = navi.ReadToEnd();
                string contenuto2 = comandanti.ReadToEnd();

                navi.Close();
                comandanti.Close();

                JSONNode j = JSONNode.Parse(contenuto1);
                Console.WriteLine("File completo navi:");
                Console.WriteLine(j.ToString(""));

                Console.WriteLine("");

                JSONNode y = JSONNode.Parse(contenuto2);
                Console.WriteLine("File completo comandanti:");
                Console.WriteLine(y.ToString(""));

                Console.WriteLine("");
                Console.WriteLine("");

                Thread.Sleep(2000);

                Console.WriteLine("RICERCA DEL COMANDANTE DATO IL NOME DELLA NAVE:");
                Console.WriteLine("");
                Console.WriteLine("Inserisci il nome della nave");
                strNave = Console.ReadLine();

                int n1 = y.Count;
                for(int i = 0; i < n1; i++)
                {
                    if (strNave == y["nave"])
                    {
                        Console.WriteLine("Trovato!");
                        Console.WriteLine(y["nome"][i].ToString(""));

                    }
                    else
                    {
                        Console.WriteLine("Errore, nome non trovato!");
                    }
                }

                Console.WriteLine("");
                Console.WriteLine("");

                Console.WriteLine("RICERCA DELLA NAVE DATO IL NOME DEL COMANDANTE:");
                Console.WriteLine("");
                Console.WriteLine("Inserisci il nome del comandante");
                strComandante = Console.ReadLine();

                int n2 = j.Count;
                for (int i = 0; i < n2; i++)
                {
                    if (strComandante == j["nome"])
                    {
                        Console.WriteLine("Trovato!");
                        Console.WriteLine(j["nome"][i].ToString(""));

                    }
                    else
                    {
                        Console.WriteLine("Errore, nome non trovato!");
                    }
                }
            }
            else
            {
                Console.WriteLine("Attendere.....");
                Console.WriteLine("");

                StreamReader navi = new StreamReader("navi.txt");
                StreamReader comandanti = new StreamReader("comandanti.txt");

                string contenuto1 = navi.ReadToEnd();
                string contenuto2 = comandanti.ReadToEnd();

                navi.Close();
                comandanti.Close();

                JSONNode j = JSONNode.Parse(contenuto1);
                JSONNode y = JSONNode.Parse(contenuto2);

                Thread.Sleep(2000);

                Console.WriteLine("RICERCA DEL COMANDANTE DATO IL NOME DELLA NAVE:");
                Console.WriteLine("");
                Console.WriteLine("Inserisci il nome della nave");
                strNave = Console.ReadLine();

                int n1 = y.Count;
                for (int i = 0; i < n1; i++)
                {
                    if (strNave == y["nave"])
                    {
                        Console.WriteLine("Trovato!");
                        Console.WriteLine(y["nome"][i].ToString(""));

                    }
                    else
                    {
                        Console.WriteLine("Errore, nome non trovato!");
                    }
                }

                Console.WriteLine("");
                Console.WriteLine("");

                Console.WriteLine("RICERCA DELLA NAVE DATO IL NOME DEL COMANDANTE:");
                Console.WriteLine("");
                Console.WriteLine("Inserisci il nome del comandante");
                strComandante = Console.ReadLine();

                int n2 = j.Count;
                for (int i = 0; i < n2; i++)
                {
                    if (strComandante == j["nome"])
                    {
                        Console.WriteLine("Trovato!");
                        Console.WriteLine(j["nome"][i].ToString(""));

                    }
                    else
                    {
                        Console.WriteLine("Errore, nome non trovato!");
                    }
                }
            }

            Console.ReadLine();
        }
    }
}