﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Fabbri.Luca._4J.FlottaNavale;

namespace Fabbri.Luca._4J.FlottaNavale.models
{
    class Nave //classe nave 
    {
        //proprietà che consentono di leggere e scrivere i campi
        string _nome;
        public string Nome
        {
            get { return _nome; }
            set { _nome = value; }
        }
        double _stazza;
        public double Stazza
        {
            get { return _stazza; }
            set { _stazza = value; }
        }
        int _velocita;
        public int Velocita
        {
            get { return _velocita; }
            set { _velocita = value; }
        }
        bool _varata;
        public bool Varata
        {
            get { return _varata; }
            set { _varata = value; }
        }

        //costruttori che assegneranno i valori ai 4 campi
        public Nave(string nome, double stazza, int velocita, bool varata)
        {
            _nome = nome;
            _stazza = stazza;
            _velocita = velocita;
            _varata = varata;
        }
        public Nave()
        { 

        }
        public Nave(string nome, double stazza, int velocita) : this(nome, stazza, velocita, false)
        { 

        }

        //metodi che svolgono operazioni sugli attributi della classe
        public override string ToString()
        {
            string tmp = "";
            tmp = String.Format("{0},{1},{2}", _nome, _stazza, _velocita);
            return tmp;
        }
        public void Vara()
        {
            _varata = true;
        }
        public bool IsVarata()
        {
            return _varata;
        }
    }
}