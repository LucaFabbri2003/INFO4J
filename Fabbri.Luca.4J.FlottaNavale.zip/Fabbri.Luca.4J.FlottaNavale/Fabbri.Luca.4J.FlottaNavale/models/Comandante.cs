﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Fabbri.Luca._4J.FlottaNavale;

namespace Fabbri.Luca._4J.FlottaNavale.models
{
    class Comandante //classe comandante
    {
        //proprietà della classe comandante che consentono di leggere e scrivere dentro i campi
        string _nome;
        public string Nome
        {
            get { return _nome; }
            set { _nome = value; }
        }
        string _nave;
        public string Nave
        {
            get { return _nave; }
            set { _nave = value; }
        }
        int _equipaggio;
        public int Equipaggio
        {
            get { return _equipaggio; }
            set { _equipaggio = value; }
        }

        //costruttori che assegneranno i valori ai 3 campi
        public Comandante(string nome, string nave, int equipaggio)
        {
            _nome = nome;
            _nave = nave;
            _equipaggio = equipaggio;
        }
        public Comandante()
        {

        }
    }
}