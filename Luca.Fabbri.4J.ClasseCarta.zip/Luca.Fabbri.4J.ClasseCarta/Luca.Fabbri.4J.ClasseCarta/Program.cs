﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Luca.Fabbri._4J.ClasseCarta
{
    class Program
    {

        static void Main(string[] args)
        {
            int Valore1 = 0, Valore2 = 0;
            string Seme1 = "", Seme2 = "";

            Console.WriteLine("Benvenuto nel programma Gioco di Carte Luca Fabbri 4J");
            Console.WriteLine("");

            Console.WriteLine("Inserisci il valore della prima carta:");
            Valore1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("");

            Console.WriteLine("Che seme ha la prima carta? (Inserire nome con lettera maiuscola)");
            Seme1 = Console.ReadLine();
            Console.WriteLine("");

            Console.WriteLine("Inserisci il valore della seconda carta:");
            Valore2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("");

            Console.WriteLine("Che seme ha la seconda carta? (Inserire nome con lettera maiuscola)");
            Seme2 = Console.ReadLine();
            Console.WriteLine("");

            Carta Carta1 = new Carta(Valore1, Seme1);
            Carta Carta2 = new Carta(Valore2, Seme2);

            Console.WriteLine(Carta1.Visualizza(Carta1));
            Console.WriteLine("");
            Console.WriteLine(Carta2.Visualizza(Carta2));
            Console.WriteLine("");
            Console.WriteLine("Valore logico:");
            Console.WriteLine(Carta1.Vince(Carta1, Carta2));
            Console.WriteLine("");
            Console.WriteLine("Ricorda! Valore 'true' se la carta risulta vincente rispetto alla carta confrontata.");
            Console.WriteLine("Mentre valore 'false' in caso contrario.");
            Console.WriteLine("");
            Console.WriteLine("Grazie per aver giocato  <3");
            Console.ReadLine();
        }
    }
    class Carta
    {
        private int _Valore = 0;
        private string _Seme = "";

        public int Valore
        {
            get
            {
                return _Valore;
            }

            set
            {
                _Valore = value;
            }
        }

        public string Seme
        {
            get
            {
                return _Seme;
            }

            set
            {
                _Seme = value;
            }
        }

        public Carta(int valore, string seme)
        {
            _Valore = valore;
            _Seme = seme;
        }

        public string Visualizza(Carta Carta1)
        {
            if(_Valore == 14)
            {
                return "La carta e' l'asso di " + _Seme;
            }
            else
            {
                return "La tua carta e' il " + _Valore + " di " + _Seme;
            }
        }

        public bool Vince(Carta Carta1, Carta Carta2)
        {
            if(Carta1._Seme == Carta2._Seme)
            {
                if(Carta1._Valore == Carta2._Valore)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
               if(Carta1._Seme=="Cuori")
               {
                    return true;
               }
               else
               {
                    if(Carta2._Seme == "Cuori")
                    {
                        return false;
                    }
                    else
                    {
                        if(Carta1._Seme == "Quadri")
                        {
                            return true;
                        }
                        else
                        {
                            if(Carta2._Seme == "Quadri")
                            {
                                return false;
                            }
                            else
                            {
                                if(Carta1._Seme == "Fiori")
                                {
                                    return true;
                                }
                                else
                                {
                                    if(Carta2._Seme == "Fiori")
                                    {
                                        return true;
                                    }
                                    else
                                    {
                                        return false;
                                    }
                                }
                            }
                        }
                    }
               }

            }
        }
    }
}